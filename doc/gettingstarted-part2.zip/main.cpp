#include <QApplication>
#include "qmlapplicationviewer.h"

//PART1: Include the plugin
#include "connectivityplugin.h"

Q_DECL_EXPORT int main(int argc, char *argv[])
{
    QScopedPointer<QApplication> app(createApplication(argc, argv));

    //PART1: Register the plugin to QML
    ConnectivityPlugin plugin;
    plugin.registerTypes("ConnectivityPlugin");

    QmlApplicationViewer viewer;
    viewer.setOrientation(QmlApplicationViewer::ScreenOrientationAuto);
    viewer.setMainQmlFile(QLatin1String("qml/gettingstarted/main.qml"));
    viewer.showExpanded();

    return app->exec();
}
